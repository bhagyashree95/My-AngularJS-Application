 var mainApp = angular.module("mainApp", ['ngRoute']);
         mainApp.config(['$routeProvider','$locationProvider',function ($routeProvider, $locationProvider) {
			 $locationProvider.hashPrefix('');
            $routeProvider
			. when('/home', {
               templateUrl: 'Pages/home.html',
               controller: 'HomeController'
            })
			
			. when('/intro', {
               templateUrl: 'Pages/intro.html',
               controller: 'IntroController'
            })
			. when('/ng-init', {
               templateUrl: 'Pages/ng-init.html',
               controller: 'NgInitController'
            })
			. when('/ng-app', {
               templateUrl: 'Pages/ng-app.html',
               controller: 'NgAppController'
            })
			. when('/ng-model', {
               templateUrl: 'Pages/ng-model.html',
               controller: 'NgModelController'
            })
			. when('/ng-controller', {
               templateUrl: 'Pages/ng-controller.html',
               controller: 'NgControllerController'
            })
			. when('/ng-bind', {
               templateUrl: 'Pages/ng-bind.html',
               controller: 'NgBindController'
            })
			. when('/ng-repeat', {
               templateUrl: 'Pages/ng-repeat.html',
               controller: 'NgRepeatController'
            })
			. when('/ng-show', {
               templateUrl: 'Pages/ng-show.html',
               controller: 'NgShowController'
            })
			. when('/ng-readonly', {
               templateUrl: 'Pages/ng-readonly.html',
               controller: 'NgReadonlyController'
            })
			. when('/ng-disabled', {
               templateUrl: 'Pages/ng-disabled.html',
               controller: 'NgDisabledController'
            })
			. when('/ng-if', {
               templateUrl: 'Pages/ng-if.html',
               controller: 'NgIfController'
            })
			. when('/ng-click', {
               templateUrl: 'Pages/ng-click.html',
               controller: 'NgClickController'
            })
			. when('/manual-bootstrap', {
               templateUrl: 'Pages/manual-bootstrap.html',
               controller: 'ManualBootstrapController'
            })
			
			. when('/customdirectives', {
               templateUrl: 'Pages/customdirectives.html',
               controller: 'CustomDirectiveController'
            })
			. when('/element', {
               templateUrl: 'Pages/element.html',
               controller: 'ElementController'
            })
			. when('/attribute', {
               templateUrl: 'Pages/attribute.html',
               controller: 'AttributeController'
            })
			. when('/class', {
               templateUrl: 'Pages/class.html',
               controller: 'ClassController'
            })			
 			. when('/comment', {
               templateUrl: 'Pages/comment.html',
               controller: 'CommentController'
            })     
 			. when('/scope-false', {
               templateUrl: 'Pages/scope-false.html',
               controller: 'ScopeFalseController'
            })  
 			. when('/scope-true', {
               templateUrl: 'Pages/scope-true.html',
               controller: 'ScopeTrueController'
            }) 	
 			. when('/scope-isolated', {
               templateUrl: 'Pages/scope-isolated.html',
               controller: 'ScopeIsolatedController'
            }) 	
 			. when('/link-function', {
               templateUrl: 'Pages/link-function.html',
               controller: 'LinkFunctionController'
            })

			. when('/constant', {
               templateUrl: 'Pages/constant.html',
               controller: 'ConstantController'
            })
			. when('/value', {
               templateUrl: 'Pages/value.html',
               controller: 'ValueController'
            })
         }]);
		 
		 
		 
		    mainApp.controller('HomeController', function($scope) {
            $scope.message = "Home Page";
		   });
		   
		   mainApp.controller('IntroController', function($scope) {
            $scope.message = "Introduction";
		   });
		    mainApp.controller('NgInitController', function($scope) {
            $scope.message = "ng-init page";
		   });		   
		    mainApp.controller('NgAppController', function($scope) {
            $scope.message = "ng-app page";
		   });		   
		    mainApp.controller('NgModelController', function($scope) {
            $scope.message = "ng-model page";
		   });		   
		   mainApp.controller('NgControllerController', function($scope) {
            $scope.message = "ng-controller page";
			$scope.firstName = "Bhagyashree";
			$scope.lastName = "B";
			$scope.fullName = function() {
			return $scope.firstName + " " + $scope.lastName;
			};
		   });
		    mainApp.controller('NgBindController', function($scope) {
            $scope.message = "ng-bind page";
		   });		   
		    mainApp.controller('NgRepeatController', function($scope) {
            $scope.message = "ng-repeat page";
			$scope.records = [
				"Bhagyashree",
				"Divya Singh",
				"SelvaPrakasam",
				"Raun",
			  ]
		   });		   
		    mainApp.controller('NgShowController', function($scope) {
            $scope.message = "ng-show page";
		   });		   
		    mainApp.controller('NgReadonlyController', function($scope) {
            $scope.message = "ng-readonly page";
		   });		   
			mainApp.controller('NgDisabledController', function($scope) {
            $scope.message = "ng-disabled page";
		   });		 
		    mainApp.controller('NgIfController', function($scope) {
            $scope.message = "ng-if page";
		   });		 
		   mainApp.controller('NgClickController', function($scope) {
            $scope.message = "ng-click page";
		   });
		   mainApp.controller('ManualBootstrapController', function($scope) {
            $scope.message = "Exception";
		   });
		   
		   mainApp.controller('CustomDirectiveController', function($scope) {
            $scope.message = "customdirectives";
		   });
			  mainApp.directive("elementDirective", function() {
				return {
			  restrict :"E",
					template : "<h1>This Example invoke a directive by using Element name</h1>"
				};
			  });
			 mainApp.controller('ElementController', function($scope) {
				$scope.message = "Element";
			   });
			  mainApp.directive("attributeDirective", function() {
				return {
				restrict : "A",
					template : "<h1>This Example invoke a directive by using Attribute </h1>"
				};
			});
			 mainApp.controller('AttributeController', function($scope) {
				$scope.message = "Attribute";
			   });
			   mainApp.directive("classDirective", function() {
				return {
					restrict : "C",
					template : "<h1>This Example invoke a directive by using Class</h1>"
				};
			}); 
			 mainApp.controller('ClassController', function($scope) {
				$scope.message = "Class";
			   });
			mainApp.directive("commentDirective", function() {
				return {
					restrict : "M",
					replace : true,
					template : "<h1>This Example invoke a directive by using Comment</h1>"
				};
			});
			 mainApp.controller('CommentController', function($scope) {
				$scope.message = "Comment";
			   });

			   mainApp.directive("movieDirective", function(){
				return {
					restrict: "E",
					scope: false,
					template: "<div>Movie title : {{movie}}</div>"+
					"Type a new movie title : <input type='text' ng-model='movie' />"
				};
			});
			  mainApp.controller('ScopeFalseController', function($scope) {
				$scope.message = "Scope False";
				$scope.movie = "Ice Age";
			   });  
			   mainApp.directive("movieDirectiveTrue", function(){
				return {
					restrict: "E",
					scope: true,
					template: "<div>Movie title : {{movie}}</div>"+
					"Type a new movie title : <input type='text' ng-model='movie' />"
				};
			});
			  mainApp.controller('ScopeTrueController', function($scope) {
				$scope.message = "Scope True";
				$scope.movie = "Ice Age";
			   }); 	
			mainApp.directive("movieDirectiveIsolated", function(){
				return {
					restrict: "E",
					scope: {
						movie: '=',
						rating: '@',
						display: '&'
					},
					template: "<div>Movie title : {{movie}}</div>"+
					"Type a new movie title : <input type='text' ng-model='movie' />"+
					"<div>Movie rating : {{rating}}</div>"+
					"Rate the movie : <input type='text' ng-model='rating' />"+
					"<div><button ng-click='display(movie)'>View Movie</button></div>"
				};
			});	 
				mainApp.controller("ScopeIsolatedController",function($scope){
				$scope.movie = "Ice Age";
				$scope.rating = 5;
				$scope.display = function(movie) {
					alert("Movie : " + movie);
				}
			});
				mainApp.directive("movieDirectiveLink", function(){
			return {
				restrict: 'E',
				scope: {
					movie: '=',
					rating: '@',
					display: '&'
				},
				template: "<div>Movie title : {{movie}}</div>"+
				"Type a new movie title : <input type='text' ng-model='movie' />"+
				"<div>Movie rating : {{rating}}</div>"+
				"Rate the movie : <input type='text' ng-model='rating' />"+
				"<div><button ng-click='display(movie)'>View Movie</button></div>",
				 
				link: function($scope, element, attrs) {
					$scope.display = function(movie) {
					alert("Movie : " + movie);
							 }
						}
					};
				});
				mainApp.controller("LinkFunctionController",function($scope){
					$scope.movie = "Ice Age";
					$scope.rating = 5;
				});

				/*
				mainApp.controller("ConstantController",function($scope, APP_NAME, APP_API){
					$scope.message = "Constant page";
					mainApp.constant('APP_NAME', 'My AngularJS App');
					mainApp.constant('APP_API', {
						'app_name': 'My AngularJS App',
						'version' : '1.0',
						'api_url' : 'https://angularjs.org/'
					$scope.app_name = APP_NAME;
					$scope.app_api = APP_API;
				});
				mainApp.controller('ValueController', function($scope) {
					$scope.message = "Value page";
					$scope.records = [
						"Bhagyashree",
						"Divya Singh",
						"SelvaPrakasam",
						"Raun",
					  ]
			   });
			   */