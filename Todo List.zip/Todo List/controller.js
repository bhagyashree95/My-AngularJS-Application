		var app= angular.module('myTodoApp', []);
			app.controller('todoCntrlr', function($scope){
				$scope.list = [{todoText:'study', done:false}];
				
				$scope.addNew = function(){
					$scope.list.push({todoText:$scope.name, done:false});
					$scope.name="";
				};
				$scope.delete= function(){
					var oldList= $scope.list;
					$scope.list = [];
					angular.forEach(oldList,function(y){
						if(!y.done) $scope.list.push(y);
					});
				};
			});