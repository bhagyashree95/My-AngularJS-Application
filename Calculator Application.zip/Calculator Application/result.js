var CalculatorApp = angular.module("CalculatorApp", ['ngRoute']);

CalculatorApp.config(function($routeProvider) {
	$routeProvider
		.when('/arithmetic', {
			templateUrl: 'arithmetic.html',
			controller: 'CalculatorController'
		})
		.when('/result', {
			templateUrl: 'result.html',
			controller: 'SuccessController'
		})
		.otherwise({
			redirectTo: '/arithmetic'
		});
});

CalculatorApp.controller('CalculatorController', function($scope, $rootScope, $location){
				$scope.result = function(){
				if($scope.operator=='ADDITION'){
					var add=$scope.a + $scope.b;
					$rootScope.result=add;
					alert($rootScope.result);
					$location.path('/result' ); 
				}
				if($scope.operator=='SUBSTRACTION'){
					var sub=$scope.a - $scope.b;
					$rootScope.result=sub;
					$location.path('/result' );
				}
				if($scope.operator=='MULTIPLICATION'){
					var mul=$scope.a * $scope.b;
					$rootScope.result=mul;
					$location.path('/result' );
				}
				if($scope.operator=='DIVISION'){
					var div=$scope.a / $scope.b;
					$rootScope.result=div;
					$location.path('/result' );
				}
				if($scope.operator=='MODULO'){
					var mod=$scope.a % $scope.b;
					$rootScope.result=mod;
					$location.path('/result' );
				}
				};
});
CalculatorApp.controller('SuccessController', function($scope,$rootScope) {
				$scope.Result=$rootScope.result;
		   });